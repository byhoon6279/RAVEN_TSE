import pefile
from iced_x86 import *
from pe_library import *
from iced_x86 import *
from typing import Union, Dict, Sequence 
from types import ModuleType
import binascii
from keystone import *
import pandas as pd
import shutil
from identify import identify
import pickle
from functools import lru_cache
from common_function import *
import multiprocessing

old_rawPointer = 0
modified_section_data = {}

@lru_cache(maxsize=None)
def get_imported_functions(pe):
    imported_functions = []
    if hasattr(pe, 'DIRECTORY_ENTRY_IMPORT'):
        for entry in pe.DIRECTORY_ENTRY_IMPORT:
            dll_name = entry.dll.decode('utf-8')
            for imp in entry.imports:
                if imp.name:
                    function_name = imp.name.decode('utf-8')
                    offset = imp.address - pe.OPTIONAL_HEADER.ImageBase
                    imported_functions.append(function_name)
    return imported_functions

@lru_cache(maxsize=None)
def get_exported_functions(pe):
    exported_functions = []
    if hasattr(pe, 'DIRECTORY_ENTRY_EXPORT'):
        for exp in pe.DIRECTORY_ENTRY_EXPORT.symbols:
            if exp.name:
                function_name = exp.name.decode('utf-8')
                offset = exp.address - pe.OPTIONAL_HEADER.ImageBase

                exported_functions.append(function_name)
    return exported_functions

@lru_cache(maxsize=None)
def is_printable(b):
    return 32 <= b < 127

def is_utf16le_string(data, start):
    """Check UTF-16 LE String"""
    length = len(data)
    for i in range(start, length, 2):
        if i + 1 >= length or data[i+1] != 0x00:
            return False
        if data[i] == 0x00 and data[i+1] == 0x00:  # 문자열의 끝을 의미
            break
    return True

def decode_utf16le_string(data, start):
    """UTF-16 LE String Decodeing"""
    end = start
    utf16le_str = []
    while end < len(data) and data[end] != 0x00:
        utf16le_str.append(chr(data[end]))
        end += 2  
    return ''.join(utf16le_str), end + 2 

def modify_data_sections(section_name = None, data = None , function_list = None):
    
    modified_data = bytearray(data)
    #print("mdd len : ",len(modified_data))
    i = 0
    letters_set = (string.ascii_lowercase + string.digits) * 5

    with open('./api.pickle', "rb") as fw:
        api_list = pickle.load(fw)
        
    while i < len(modified_data):
        try:
            if is_printable(modified_data[i]):
                start = i
                
                if is_utf16le_string(modified_data, start):
                    utf16_text, end = decode_utf16le_string(modified_data, start)
                    
                    if  (
                            (re.findall(r'(%[-+0# ]*\d*(?:\.\d+)?[diuoxXfFeEgGaAcspn])', utf16_text)) 
                            or 
                            (
                                re.findall(r'\b[a-zA-Z0-9][a-zA-Z0-9\s\.,;:!?\'"()\[\]{}<>-]{5,}\b', utf16_text)  
                                and not re.findall(r'[-+#/\?^@\"※~ㆍ』;*%\{\}\<\>‘|\[\]`\'…》\”\“\’·$=_:&]', utf16_text)
                            ) 
                            or 
                            (
                                '\\' in utf16_text 
                                and len(utf16_text) > 5 
                                and not re.findall(r'[-+,#/\?^@\"※~ㆍ!』;*%\{\}\<\>‘|\(\)\[\]`\'…》\”\“\’·$=_:.&]', utf16_text) 
                                and not re.findall(r'[0-9]+', utf16_text)
                            )
                            or 
                            (
                                re.findall(r'(?:[a-zA-Z0-9-]{1,63}\.)+[a-zA-Z]{2,63}', utf16_text) 
                                and not re.findall(r'<[^>]+>', utf16_text) 
                                and not re.findall(r'=', utf16_text)
                            )
                        ):
                        
                        if len(modified_data[start:end]) <= len(letters_set):
                            random_list = random.sample(letters_set, int(len(modified_data[start:end])/2))
                            
                        else:
                            random_list = random.choices(letters_set, k=int(len(modified_data[start:end])/2))
                    
                        modified_text = ''.join(random_list)
                        modified_utf16_data = bytearray(modified_text.encode('utf-16le'))
                        
                    else:
                        modified_utf16_data = modified_data[start:end]
                    
                    modified_data[start:end] = modified_utf16_data
                    i = end
                    continue
                
                
                while i < len(modified_data) and is_printable(modified_data[i]):
                    i += 1
                    
                end = i
                text = modified_data[start:end].decode('ascii', errors='ignore')             
                txt_type = identify.tags_from_filename(text.strip())
                
                if ('.dll' in text.lower() and 'binary' in txt_type) or ('.dll' in text.lower()):
                    text = text.split('.')[0]
                    if text.isupper():
                        new_text = text + '.dll'
                        modified_text = new_text.lower().encode('ascii')
                    else:
                        new_text = text + '.dll'
                        modified_text = new_text.upper().encode('ascii')
                        
                    modified_data[start:end] = modified_text
                    continue
                    
                                    
                elif (
                        'image' in txt_type or 'plain-text' in txt_type or 'audio' in txt_type or 'html' in txt_type 

                        
                        or (
                            re.findall(r'(%[-+0# ]*\d*(?:\.\d+)?[diuoxXfFeEgGaAcspn])', text)  
                            or 
                            (  
                                re.findall(r'\b[a-zA-Z0-9][a-zA-Z0-9\s\.,;:!?\'"()\[\]{}<>-]{5,}\b', text) 
                                and not re.findall(r'[-+#/\?^@\"※~ㆍ』;*%\{\}\<\>‘|\[\]`\'…》\”\“\’·$=:&]', text) 
                            )
                        )

                        
                        or (
                            '\\' in text 
                            and len(text) > 5 
                            and not re.findall(r'[-+,#/\?^@\"※~ㆍ!』;*%\{\}\<\>‘|\(\)\[\]`\'…》\”\“\’·$=_:.&]', text)  
                            and not re.findall(r'[0-9]+', text)  
                        )

                        
                        or (
                            re.findall(r'(?:[a-zA-Z0-9-]{1,63}\.)+[a-zA-Z]{2,63}', text)  
                            and not re.findall(r'<[^>]+>', text)  
                            and not re.findall(r'=', text)  
                        )
                    ):
        
                    format_specifier = ''
                    
                    if text in api_list:
                        modified_text = modified_data[start:end]
                        modified_text = bytes(modified_text)
                        modified_data[start:end] = modified_text
                        continue
                        
                    if len(text)>5 and re.findall(r'(%[-+0# ]*\d*(?:\.\d+)?[diuoxXfFeEgGaAcspn])',text):
                        format_specifier = re.findall(r'(%[-+0# ]*\d*(?:\.\d+)?[diuoxXfFeEgGaAcspn])',text)[0]
                        last_text= text.split(format_specifier)[-1]
                        text = text.split(format_specifier)[0]
                        
                        format_specifier = format_specifier + last_text

                    if len(text) <= len(letters_set):
                        random_list = random.sample(letters_set, len(text))
                    else:
                        random_list = random.choices(letters_set, k=len(text))
                    

                    modified_text = ''.join(random_list)
                    
                    if format_specifier:
                        modified_text = modified_text+format_specifier
                        
                    modified_text = bytes(modified_text, 'utf-8')
                    modified_data[start:end] = modified_text
                    continue

                else:
                    modified_text = modified_data[start:end]
                    modified_text = bytes(modified_text)
                    modified_data[start:end] = modified_text
                    continue
            else:
                i += 1

        except Exception as e:
            print(f"Error processing text: {text}, section {section_name}: {str(e)}")

            i = end 
            continue

    print(f"Returning modified data for section: {section_name}, {len(modified_data)}")
    return bytes(modified_data)



@lru_cache(maxsize=None)
def change_resource_case(file_path, output_path):
    pe = pefile.PE(file_path)
    pe_data = open(file_path, "rb").read()
    
    import_function = get_imported_functions(pe)
    export_function = get_exported_functions(pe)

    modified_data = bytearray()

    function_list = import_function + export_function

    try:
        for section_idx, section in enumerate(pe.sections):
            section_name = section.Name.decode('utf-8', errors='ignore').strip('\x00').lower()

            if section_idx == 0:
                modified_data += pe.header

            if section.Characteristics & pefile.SECTION_CHARACTERISTICS['IMAGE_SCN_CNT_INITIALIZED_DATA'] and \
                section.Characteristics & pefile.SECTION_CHARACTERISTICS['IMAGE_SCN_MEM_READ'] or \
                section.Characteristics & pefile.SECTION_CHARACTERISTICS['IMAGE_SCN_MEM_WRITE']:

                print(f"Processing section: {section_name}")

                section_start = section.PointerToRawData
                section_end = section_start + section.SizeOfRawData

                section_data = pe_data[section_start:section_end]
                modified_rdata = modify_data_sections(section.Name.decode('utf-8', errors='ignore').strip('\x00'), section_data, function_list)
                print(f"Modified section data returned for {section_name}, {len(section_data)}")

                modified_data += modified_rdata

            else:
                print(f"Skipping section: {section_name}")
                section_start = section.PointerToRawData
                section_end = section_start + section.SizeOfRawData

                section_data = pe_data[section_start:section_end]
                modified_data += section_data

        last_section_end = pe.sections[-1].PointerToRawData + pe.sections[-1].SizeOfRawData
        if len(pe_data) > last_section_end:
            overlay_data = pe_data[last_section_end:]
            print("Overlay data detected and will be processed.")
            modified_overlay_data = modify_data_sections("overlay", overlay_data, function_list)
            modified_data += modified_overlay_data

    except Exception as e:
        print(f"Error in processing PE file: {str(e)}")

    output_file = os.path.join(output_path, os.path.basename(file_path.replace(".exe", "_resource_change.exe")))
    with open(output_file, "wb") as f:
        f.write(modified_data)

    pe.close()
       
def process_sample(args):
    sample, root, save_dir = args
    file_path = os.path.join(root, sample)
    
    try:
        change_resource_case(file_path, save_dir)
        print(f"Resource case changed for {sample}\n")
        
    except pefile.PEFormatError:
        pass      

def main():

    sample = "calc.exe"
    root = "./"
    save_dir = "./temp/"

    process_sample((sample, root, save_dir))
      
